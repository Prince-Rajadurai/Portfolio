package com.zoho.zs.session;

import com.zoho.mickey.installer.MickeyStandalone;

import java.io.OutputStream;
import java.io.PrintStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;

/**
 * Manages the MickeyLite standalone lifecycle — start, run user code, stop.
 *
 * <p>Installation is handled at build time by the {@code setupMickey} Gradle task.
 * All installer properties are configured in {@code gradle.properties}.
 *
 * <p>Usage:
 * <pre>
 *   MickeySession.run(ctx -> {
 *       // your mickey code here — server is running
 *       System.out.println("Server home: " + ctx.getServerHome());
 *   });
 * </pre>
 */
public class MickeySession {

    private static final Logger LOGGER = Logger.getLogger(MickeySession.class.getName());

    /**
     * Context passed to {@link MickeyTask#execute} — gives access to
     * the server home path.
     */
    public static class Context {
        private final Path serverHome;

        Context(Path serverHome) {
            this.serverHome = serverHome;
        }

        public Path getServerHome() { return serverHome; }
    }

    /**
     * Starts the standalone server, executes the task, then stops the server.
     *
     * <p>The server home is resolved from:
     * <ol>
     *   <li>{@code server.home} system property (set by {@code ./gradlew run})</li>
     *   <li>Fallback: {@code build/builds/me_<db.type>/AdventNet/MickeyLite}</li>
     * </ol>
     */
    public static void run(MickeyTask task) throws Exception {
        boolean verbose = Boolean.getBoolean("mickey.session.verbose");
        if (!verbose) {
            suppressLogs();
        }

        Path serverHome = resolveServerHome();
        LOGGER.info("Server home: " + serverHome);

        if (!serverHome.toFile().exists()) {
            throw new IllegalStateException(
                    "Server home does not exist: " + serverHome.toAbsolutePath()
                    + "\nRun './gradlew setupMickey' first to install MickeyLite.");
        }

        System.setProperty("server.home", serverHome.toAbsolutePath().toString());
        LOGGER.info("Server home: " + serverHome);

        // ── Start ──────────────────────────────────────────────────────
        LOGGER.info("Starting standalone server...");
        MickeyStandalone.startServer(serverHome.toString());
        LOGGER.info("Standalone server is running.");

        try {
            // ── Execute user code ──────────────────────────────────────
            task.execute(new Context(serverHome));
        } finally {
            // ── Stop (always) ──────────────────────────────────────────
            LOGGER.info("Stopping standalone server...");
            try {
                MickeyStandalone.stopServer(serverHome.toString());
                LOGGER.info("Server stopped.");
            } catch (Exception e) {
                LOGGER.log(Level.SEVERE, "Error stopping server", e);
            }
            // Force exit — MickeyLite leaves non-daemon threads running
            System.exit(0);
        }
    }

    /**
     * Resolves the server home path:
     * 1. From {@code server.home} system property (set by Gradle run task)
     * 2. Fallback: {@code build/builds/me_<dbType>/AdventNet/MickeyLite}
     */
    /**
     * Suppresses all JUL logging and stdout/stderr noise from MickeyLite internals.
     * Restores stdout/stderr after server start so user code prints normally.
     */
    private static void suppressLogs() {
        // Silence all java.util.logging output
        LogManager.getLogManager().reset();
        Logger rootLogger = Logger.getLogger("");
        rootLogger.setLevel(Level.OFF);
    }

    private static Path resolveServerHome() {
        String serverHomeProp = System.getProperty("server.home");
        if (serverHomeProp != null) {
            return Paths.get(serverHomeProp);
        }

        // Fallback: derive from mickey.setup.db.type (default: pgsql_b)
        String dbType = System.getProperty("mickey.setup.db.type", "pgsql_b");
        return Paths.get("build", "builds", "me_" + dbType, "AdventNet", "MickeyLite");
    }
}
