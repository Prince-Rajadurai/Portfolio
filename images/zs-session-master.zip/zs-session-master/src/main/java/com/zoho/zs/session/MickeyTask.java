package com.zoho.zs.session;

/**
 * User-implemented interface for code that runs against a live MickeyLite
 * standalone server.
 *
 * <p>The lifecycle is managed by {@link MickeySession}:
 * <ol>
 *   <li>MickeyLite is installed (if needed)</li>
 *   <li>Standalone server is started</li>
 *   <li>{@link #execute(MickeySession.Context)} is called</li>
 *   <li>Standalone server is stopped</li>
 * </ol>
 */
@FunctionalInterface
public interface MickeyTask {

    /**
     * Implement your mickey code here. The standalone server is already
     * running when this method is invoked.
     *
     * @param ctx provides access to the installer and server home path
     * @throws Exception propagated to the caller after the server is stopped
     */
    void execute(MickeySession.Context ctx) throws Exception;
}
