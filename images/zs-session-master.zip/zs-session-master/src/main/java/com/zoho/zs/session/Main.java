package com.zoho.zs.session;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.Table;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;

import java.util.Iterator;

/**
 * Entry point — starts the MickeyLite standalone server, runs user code, stops.
 *
 * <p>All configuration is in {@code gradle.properties}. Run via:
 * <pre>
 *   ./gradlew run
 * </pre>
 */
public class Main {

    public static void main(String[] args) throws Exception {

        MickeySession.run(ctx -> {
            System.out.println("Server home : " + ctx.getServerHome());

            // ── Build a SelectQuery on the Module table ────────────────
            SelectQuery selectQuery = new SelectQueryImpl(new Table("Module"));
            selectQuery.addSelectColumn(new Column("Module", "*"));

            // ── Execute and get DataObject ─────────────────────────────
            DataObject dataObject = DataAccess.get(selectQuery);

            // ── Iterate rows and print ─────────────────────────────────
            Iterator<Row> rows = dataObject.getRows("Module");
            System.out.println("--- Module table rows ---");
            while (rows.hasNext()) {
                Row row = rows.next();
                System.out.println("MODULE_ID=" + row.get("MODULE_ID")
                        + ", MODULENAME=" + row.get("MODULENAME"));
            }
            System.out.println("--- End ---");
        });
    }
}
