import org.gradle.api.DefaultTask
import org.gradle.api.GradleException
import org.gradle.api.file.DirectoryProperty
import org.gradle.api.file.RegularFileProperty
import org.gradle.api.provider.MapProperty
import org.gradle.api.provider.Property
import org.gradle.api.tasks.*
import org.gradle.process.ExecOperations
import javax.inject.Inject

/**
 * Gradle task that sets up a Mickey server environment using MickeyInstaller.
 *
 * Runs `MickeyInstaller initialize` as a forked Java process with all
 * configured properties passed as system properties.
 *
 * ## Common Properties (mickey.setup.*)
 * - `mickey.setup.db.type`     — Database type (mysql, pgsql, pgsql_b, mssql)
 * - `mickey.setup.db.hostname` — Database host
 * - `mickey.setup.db.port`     — Database port
 * - `mickey.setup.db.username` — Database username
 * - `mickey.setup.db.password` — Database password
 * - `mickey.setup.url`         — Mickey build download URL
 * - `mickey.setup.port`        — Server port
 */
abstract class SetupMickey @Inject constructor(
    private val execOperations: ExecOperations
) : DefaultTask() {

    @get:Input
    abstract val type: Property<String>

    @get:InputFile
    abstract val installerJar: RegularFileProperty

    @get:InputFile
    @get:Optional
    abstract val buildFile: RegularFileProperty

    @get:Input
    @get:Optional
    abstract val buildUrl: Property<String>

    @get:Input
    abstract val setupProperties: MapProperty<String, String>

    @get:Input
    @get:Optional
    abstract val forceSetup: Property<Boolean>

    @get:OutputDirectory
    abstract val destinationDir: DirectoryProperty

    @get:Internal
    abstract val mickeyHome: DirectoryProperty

    init {
        type.convention("me")
        forceSetup.convention(false)

        destinationDir.convention(project.provider { calculateDestinationDir() })

        mickeyHome.convention(destinationDir.map { dir ->
            val buildType = type.get().lowercase()
            val suffix = if (buildType == "me") "AdventNet/MickeyLite" else "AdventNet/Sas/tomcat/webapps/test/WEB-INF"
            dir.dir(suffix)
        })

        outputs.upToDateWhen {
            val force = forceSetup.get()
            if (force) {
                println("SetupMickey: forceSetup=true, will reinstall")
                false
            } else {
                val destDir = calculateDestinationDir()
                val buildType = type.get().lowercase()
                val suffix = if (buildType == "me") "AdventNet/MickeyLite" else "AdventNet/Sas/tomcat/webapps/test/WEB-INF"
                val home = destDir.dir(suffix).asFile
                val marker = java.io.File(home, "mickeysetupinfo.props")
                val exists = marker.exists()
                println("SetupMickey: forceSetup=false, marker=${marker.absolutePath}, exists=$exists")
                exists
            }
        }
    }

    @TaskAction
    fun execute() {
        val buildType = type.get().lowercase()
        require(buildType in listOf("me", "cloud")) {
            "Invalid build type: $buildType. Supported: me, cloud."
        }

        val destination = destinationDir.get().asFile
        if (!destination.exists()) {
            destination.mkdirs()
        }

        val isCloud = buildType == "cloud"
        val propsPrefix = if (isCloud) "mickey.cloud.setup." else "mickey.setup."
        val installerMainClass = if (isCloud) "com.zoho.mickey.installer.MickeyCloudInstaller" else "com.zoho.mickey.installer.MickeyInstaller"

        val mergedProps = if (setupProperties.isPresent) setupProperties.get().toMutableMap() else mutableMapOf()

        val destinationKey = "${propsPrefix}destination"
        val dbTypeKey = "${propsPrefix}db.type"
        val pathKey = "${propsPrefix}path"
        val urlKey = "${propsPrefix}url"

        val defaultDbType = if (isCloud) "mysql" else "pgsql_b"
        val effectiveDbType = mergedProps[dbTypeKey] ?: defaultDbType

        execOperations.javaexec {
            mainClass.set(installerMainClass)
            classpath(installerJar)
            args("initialize")

            systemProperty(destinationKey, destination.absolutePath)
            systemProperty(dbTypeKey, effectiveDbType)

            when {
                buildFile.isPresent && buildFile.get().asFile.exists() -> {
                    systemProperty(pathKey, buildFile.get().asFile.absolutePath)
                }
                buildUrl.isPresent -> {
                    systemProperty(urlKey, buildUrl.get())
                }
                mergedProps.containsKey(urlKey) -> {
                    systemProperty(urlKey, mergedProps[urlKey]!!)
                }
                mergedProps.containsKey(pathKey) -> {
                    systemProperty(pathKey, mergedProps[pathKey]!!)
                }
                else -> {
                    throw GradleException(
                        "No Mickey build source provided. Set buildUrl or provide mickey.setup.url in setupProperties."
                    )
                }
            }

            mergedProps.forEach { (key, value) ->
                systemProperty(key, value)
            }
        }
    }

    private fun calculateDestinationDir(): org.gradle.api.file.Directory {
        val buildType = type.get().lowercase()
        val isCloud = buildType == "cloud"
        val propsPrefix = if (isCloud) "mickey.cloud.setup." else "mickey.setup."
        val destKey = "${propsPrefix}destination"

        if (setupProperties.isPresent) {
            val props = setupProperties.get()
            val propDest = props[destKey]
            if (propDest != null) {
                return project.layout.dir(project.provider { project.file(propDest) }).get()
            }
        }

        var effectiveDbType: String? = null
        if (setupProperties.isPresent) {
            val dbTypeKey = "${propsPrefix}db.type"
            effectiveDbType = setupProperties.get()[dbTypeKey]
        }
        if (effectiveDbType == null) {
            effectiveDbType = if (isCloud) "mysql" else "pgsql_b"
        }

        val subPath = if (isCloud) "builds/cloud_$effectiveDbType" else "builds/me_$effectiveDbType"
        return project.layout.buildDirectory.dir(subPath).get()
    }
}
