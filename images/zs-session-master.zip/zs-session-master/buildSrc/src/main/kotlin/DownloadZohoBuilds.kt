import de.undercouch.gradle.tasks.download.DownloadExtension
import org.gradle.api.DefaultTask
import org.gradle.api.file.RegularFileProperty
import org.gradle.api.provider.Property
import org.gradle.api.tasks.Input
import org.gradle.api.tasks.OutputFile
import org.gradle.api.tasks.TaskAction
import java.io.File
import java.util.*
import java.util.concurrent.ArrayBlockingQueue

abstract class DownloadZohoBuilds : DefaultTask() {
    data class Credential(val username: String, val password: String)

    private val wgetrcFile = File(System.getProperty("user.home"), ".wgetrc")

    @get:Input
    abstract val downloadUrl: Property<String>

    @get:OutputFile
    abstract val downloadFile: RegularFileProperty

    private val credentials: List<Credential>

    init {
        require(wgetrcFile.exists()) { "No .wgetrc file found in ${wgetrcFile.parent}" }

        credentials = wgetrcFile.readLines()
            .asSequence()
            .filter { it.startsWith("user=") || it.startsWith("password=") }
            .windowed(2, 2, false)
            .onEach { (user, password) ->
                require(user.startsWith("user=")) { "Invalid user line: $user" }
                require(password.startsWith("password=")) { "Invalid password line: $password" }
            }
            .map { (user, password) -> user.substringAfter("=") to password.substringAfter("=") }
            .onEach { (user, password) ->
                require(user.isNotBlank()) { "Empty user name" }
                require(password.isNotBlank()) { "Empty password" }
            }
            .map { Credential(it.first.trim(), it.second.trim()) }
            .toList()

        require(credentials.isNotEmpty()) { "No credentials found in $wgetrcFile to download $downloadUrl" }
    }

    @TaskAction
    fun download() {
        val creds = ArrayBlockingQueue(credentials.size, false, credentials)
        while (creds.isNotEmpty()) {
            val credential = creds.poll()
            println("Trying with ${credential.username}")
            try {
                DownloadExtension(project).run {
                    src(downloadUrl)
                    dest(downloadFile)
                    onlyIfModified(true)
                    overwrite(false)
                    retries(3)
                    preemptiveAuth(true)
                    val basicAuth = "Basic " + Base64.getEncoder()
                        .encodeToString((credential.username + ":" + credential.password).toByteArray())
                    headers(mapOf("authorization" to basicAuth))
                }
                break
            } catch (e: Exception) {
                if (e.message?.contains("401") == false) {
                    e.printStackTrace()
                    throw e
                }
                if (creds.isEmpty()) {
                    e.printStackTrace()
                    throw e
                }
                println("Failed with ${credential.username}")
            }
        }
    }
}
