plugins {
    `kotlin-dsl`
}

repositories {
    gradlePluginPortal()
}

dependencies {
    implementation("de.undercouch.download:de.undercouch.download.gradle.plugin:5.5.0")
}
