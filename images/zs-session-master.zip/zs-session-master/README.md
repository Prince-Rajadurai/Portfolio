# zs-session

A simple Gradle project that installs MickeyLite and starts a standalone persistence server using `MickeySession`.

## Prerequisites

1. **Java 11+**
2. **Gradle 8.x** (or use the included `./gradlew` wrapper)
3. **`~/.wgetrc`** with build server credentials:
   ```
   user=<your-username>
   password=<your-password>
   ```

## Usage

```bash
./gradlew run
```

Edit `gradle.properties` to configure MickeyLite URL, DB type, port, etc.  
Write your persistence code inside the lambda in `Main.java`.
