plugins {
    java
    application
}

repositories {
    mavenCentral()
}

java {
    toolchain {
        languageVersion.set(JavaLanguageVersion.of(11))
    }
}

// ── All URLs configured in gradle.properties ───────────────────────────────────

val mickeyQAUtilsUrl: String by project
val mickeyStandaloneUrl: String by project

// ── Download mickeyqa-utils and mickeyqa-standalone jars ────────────────────────

val downloadMickeyQAUtils = tasks.register<DownloadZohoBuilds>("downloadMickeyQAUtils") {
    downloadUrl.set(mickeyQAUtilsUrl)
    downloadFile.set(layout.projectDirectory.file("libs/mickeyqa-utils.jar"))
}

val downloadMickeyStandalone = tasks.register<DownloadZohoBuilds>("downloadMickeyStandalone") {
    downloadUrl.set(mickeyStandaloneUrl)
    downloadFile.set(layout.projectDirectory.file("libs/mickeyqa-standalone-utils.jar"))
}

// ── Install MickeyLite via SetupMickey ─────────────────────────────────────────

// Collect all mickey.setup.* properties from gradle.properties
val mickeySetupProps = project.properties
    .filterKeys { it.startsWith("mickey.setup.") }
    .mapValues { it.value.toString() }
    .toMutableMap()

val setupMickey = tasks.register<SetupMickey>("setupMickey") {
    type.set("me")
    installerJar.set(downloadMickeyQAUtils.flatMap { it.downloadFile })
    setupProperties.set(mickeySetupProps)
}

// Compute mickey home path deterministically (must match SetupMickey's convention)
val dbType = mickeySetupProps.getOrDefault("mickey.setup.db.type", "pgsql_b")
val mickeyHomeDir = layout.buildDirectory.dir("builds/me_$dbType/AdventNet/MickeyLite")

// ── Wire up dependencies ───────────────────────────────────────────────────────

tasks.compileJava {
    dependsOn(downloadMickeyQAUtils, downloadMickeyStandalone)
}

dependencies {
    // MickeyLite jars from the installed server — listed FIRST so its newer
    // PostgreSQL driver (42.7.7) takes precedence over the older one bundled
    // inside mickeyqa-utils.jar
    implementation(fileTree(mickeyHomeDir.map { it.dir("lib") }) {
        include("**/*.jar")
    })
    implementation(fileTree(mickeyHomeDir.map { it.dir("bin") }) {
        include("**/*.jar")
    })

    // mickeyqa-utils fat jar (contains MickeyInstaller + StructuralAPI etc.)
    implementation(files("libs/mickeyqa-utils.jar"))

    // mickeyqa-standalone jar (contains MickeyStandalone)
    implementation(files("libs/mickeyqa-standalone-utils.jar"))
}

application {
    mainClass.set("com.zoho.zs.session.Main")
}

tasks.named<JavaExec>("run") {
    dependsOn(setupMickey)

    // Pass server.home so MickeyStandalone can find its files
    systemProperty("server.home", mickeyHomeDir.get().asFile.absolutePath)

    // Forward all mickey.setup.* properties to the runtime
    mickeySetupProps.forEach { (key, value) -> systemProperty(key, value) }

    // Forward session verbosity flag
    project.findProperty("mickey.session.verbose")?.let {
        systemProperty("mickey.session.verbose", it.toString())
    }

    // Forward any additional mickey.* system properties from the command line
    System.getProperties().stringPropertyNames()
        .filter { it.startsWith("mickey.") }
        .forEach { key -> systemProperty(key, System.getProperty(key)) }
}

tasks.test {
    useJUnitPlatform()
}

