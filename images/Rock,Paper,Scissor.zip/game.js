let player1 = "";
let player1score=0;
let player2 = "";
let player2score=0;
let count = 0;
let option = ["rock", "paper", "scissor", "lizard", "spock"];
let computer = "";

document.querySelector("#rock").addEventListener("click", function () {
    if (player1 == "") {
        player1 = "rock"; verify();
    }
})

document.querySelector("#rock1").addEventListener("click", function () {
    if (player1 == "") {
        player1 = "rock"; count += 1; check();
    }
    else{
        alert("Your turn is over");
    }
})

document.querySelector("#rock2").addEventListener("click", function () {
    if (player2 == "") {
        player2 = "rock"; count += 1; check();
    }
    else{
        alert("Your turn is over");
    }
})

document.querySelector("#paper").addEventListener("click", function () {
    if (player1 == "") {
        player1 = "paper"; verify();
    }
})

document.querySelector("#paper1").addEventListener("click", function () {
    if (player1 == "") {
        player1 = "paper"; count += 1; check();
    }
    else{
        alert("Your turn is over");
    }
})

document.querySelector("#paper2").addEventListener("click", function () {
    if (player2 == "") {
        player2 = "paper"; count += 1; check();
    }
    else{
        alert("Your turn is over");
    }
})

document.querySelector("#scissor").addEventListener("click", function () {
    if (player1 == "") {
        player1 = "scissor"; verify();
    }
})

document.querySelector("#scissor1").addEventListener("click", function () {
    if (player1 == "") {
        player1 = "scissor"; count += 1; check();
    }
    else{
        alert("Your turn is over");
    }
})

document.querySelector("#scissor2").addEventListener("click", function () {
    if (player2 == "") {
        player2 = "scissor"; count += 1; check();
    }
    else{
        alert("Your turn is over");
    }
})

document.querySelector("#lizard").addEventListener("click", function () {
    if (player1 == "") {
        player1 = "lizard"; verify();
    }
})

document.querySelector("#lizard1").addEventListener("click", function () {
    if (player1 == "") {
        player1 = "lizard"; count += 1; check();
    }
    else{
        alert("Your turn is over");
    }
})

document.querySelector("#lizard2").addEventListener("click", function () {
    if (player2 == "") {
        player2 = "lizard"; count += 1; check();
    }
    else{
        alert("Your turn is over");
    }
})

document.querySelector("#spock").addEventListener("click", function () {
    if (player1 == "") {
        player1 = "spock"; verify();
    }
})

document.querySelector("#spock1").addEventListener("click", function () {
    if (player1 == "") {
        player1 = "spock"; count += 1; check();
    }
    else{
        alert("Your turn is over");
    }
})

document.querySelector("#spock2").addEventListener("click", function () {
    if (player2 == "") {
        player2 = "spock"; count += 1; check();
    }
    else{
        alert("Your turn is over");
    }
})

function check() {
    document.getElementById("player1").innerText = player1;
    document.getElementById("player2").innerText = player2;
    if (count == 2) {
        if (player1 == player2) {
            document.getElementById("winner").innerText = "It's a Draw";
        }
        else if ((player1 == "rock" && player2 == "scissor") || (player1 == "rock" && player2 == "lizard")) {
            document.getElementById("winner").innerText = "Player 1 is the winner";
        }
        else if ((player1 == "paper" && player2 == "rock") || (player1 == "paper" && player2 == "spock")) {
            document.getElementById("winner").innerText = "Player 1 is the winner";
        }
        else if ((player1 == "scissor" && player2 == "paper") || (player1 == "scissor" && player2 == "lizard")) {
            document.getElementById("winner").innerText = "Player 1 is the winner";
        }
        else if ((player1 == "lizard" && player2 == "paper") || (player1 == "lizard" && player2 == "spock")) {
            document.getElementById("winner").innerText = "Player 1 is the winner";
        }
        else if ((player1 == "spock" && player2 == "scissor") || (player1 == "spock" && player2 == "rock")) {
            document.getElementById("winner").innerText = "Player 1 is the winner";
        }
        else {
            document.getElementById("winner").innerText = "Player 2 is the winner";
        }


        if(document.getElementById("winner").innerText == "Player 1 is the winner"){
            player1score++;
            document.getElementById("play1score").innerText=player1score;
            if(player1score == 5){
                document.querySelector("#who").innerText = "1";
                document.querySelector("#winpop").style.display = "flex";
                player1score=0;
                document.getElementById("play1score").innerText=player1score;
                player2score=0;
                document.getElementById("play2score").innerText=player2score;
            }
        }
        else{
            player2score++;
            document.getElementById("play2score").innerText=player2score;
            if(player2score == 5){
                document.querySelector("#who").innerText = "2";
                document.querySelector("#winpop").style.display = "flex";
                player1score=0;
                document.getElementById("play1score").innerText=player1score;
                player2score=0;
                document.getElementById("play2score").innerText=player2score;
            }

        }

        player1 = "";
        player2 = "";
        count = 0;
    }
}

function verify() {
    document.getElementById("player").innerText = player1;
    computer = option[Math.floor(Math.random() * option.length)];
    document.getElementById("computer").innerText = computer;
    if (player1 == computer) {
        document.getElementById("win").innerText = "It's a Draw";
    }
    else if ((player1 == "rock" && computer == "scissor") || (player1 == "rock" && computer == "lizard")) {
        document.getElementById("win").innerText = "Player 1 is the winner";
    }
    else if ((player1 == "paper" && computer == "rock") || (player1 == "paper" && computer == "spock")) {
        document.getElementById("win").innerText = "Player 1 is the winner";
    }
    else if ((player1 == "scissor" && computer == "paper") || (player1 == "scissor" && computer == "lizard")) {
        document.getElementById("win").innerText = "Player 1 is the winner";
    }
    else if ((player1 == "lizard" && computer == "paper") || (player1 == "lizard" && computer == "spock")) {
        document.getElementById("win").innerText = "Player 1 is the winner";
    }
    else if ((player1 == "spock" && computer == "scissor") || (player1 == "spock" && computer == "rock")) {
        document.getElementById("win").innerText = "Player 1 is the winner";
    }
    else {
        document.getElementById("win").innerText = "Computer is the winner";
    }

    player1 = "";

}

document.querySelector("#exit1").addEventListener("click", function(){
    document.querySelector("#playervscomputer").style.display = "none";
    document.querySelector("#playervsplayer").style.display = "none";
    document.querySelector("#home").style.display = "block";
})

document.querySelector("#exit2").addEventListener("click", function(){
    document.querySelector("#playervscomputer").style.display = "none";
    document.querySelector("#playervsplayer").style.display = "none";
    document.querySelector("#home").style.display = "block";
})



document.querySelector("#pvpbutton").addEventListener("click", function () {
    document.querySelector("#playervsplayer").style.display = "block";
    document.querySelector("#home").style.display = "none";
})

document.querySelector("#pvcbutton").addEventListener("click", function () {
    document.querySelector("#playervscomputer").style.display = "block";
    document.querySelector("#home").style.display = "none";
})

document.querySelector("#continue").addEventListener("click",function(){
    document.querySelector("#winpop").style.display = "none";
})

























